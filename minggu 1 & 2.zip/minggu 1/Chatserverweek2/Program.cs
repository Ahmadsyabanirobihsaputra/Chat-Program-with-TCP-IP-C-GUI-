﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ChatServerWeek2
{
    class Program
    {
        private static TcpListener? listener;
        private static readonly Dictionary<string, TcpClient> clients = new Dictionary<string, TcpClient>();
        private static readonly object locker = new object();

        static async Task Main(string[] args)
        {
            int port = 5000;
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            Console.WriteLine($"[Server] Running on port {port}");

            while (true)
            {
                TcpClient client = await listener.AcceptTcpClientAsync();
                _ = HandleClientAsync(client);
            }
        }

        private static async Task HandleClientAsync(TcpClient client)
        {
            string username = "";
            try
            {
                var stream = client.GetStream();
                byte[] buffer = new byte[1024];

                // --- baca username pertama kali ---
                int byteCount = await stream.ReadAsync(buffer, 0, buffer.Length);
                username = Encoding.UTF8.GetString(buffer, 0, byteCount).Trim();

                lock (locker)
                {
                    if (clients.ContainsKey(username))
                    {
                        byte[] failMsg = Encoding.UTF8.GetBytes("[Server] Username already taken.");
                        stream.Write(failMsg, 0, failMsg.Length);
                        client.Close();
                        return;
                    }
                    clients.Add(username, client);
                }

                BroadcastSystem($"[System] {username} has joined the chat.");
                SendUserList();

                Console.WriteLine($"[Server] {username} connected.");

                // --- loop baca pesan ---
                while (true)
                {
                    byteCount = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (byteCount == 0) break; // client disconnect

                    string msg = Encoding.UTF8.GetString(buffer, 0, byteCount);
                    Console.WriteLine($"[Recv] {msg}");

                    if (msg.StartsWith("/w ")) // private message
                    {
                        string[] parts = msg.Split(' ', 3);
                        if (parts.Length >= 3)
                        {
                            string target = parts[1];
                            string pm = $"{username} (PM): {parts[2]}";
                            SendPrivate(target, pm);
                        }
                    }
                    else if (msg.StartsWith("[TYPING]")) // <<< indikator typing
                    {
                        // langsung forward ke semua client lain
                        Broadcast(msg, exclude: username);
                    }
                    else // pesan biasa
                    {
                        Broadcast($"{username}: {msg}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Error] {ex.Message}");
            }
            finally
            {
                if (!string.IsNullOrEmpty(username))
                {
                    lock (locker) { clients.Remove(username); }
                    BroadcastSystem($"[System] {username} has left the chat.");
                    SendUserList();
                }
                client.Close();
            }
        }

        private static void Broadcast(string message, string? exclude = null)
        {
            byte[] data = Encoding.UTF8.GetBytes(message);
            lock (locker)
            {
                foreach (var kvp in clients)
                {
                    string uname = kvp.Key;
                    var c = kvp.Value;
                    if (exclude != null && uname == exclude) continue; // jangan kirim balik ke pengirim

                    try { c.GetStream().Write(data, 0, data.Length); }
                    catch { /* abaikan error */ }
                }
            }
        }

        private static void BroadcastSystem(string message)
        {
            Console.WriteLine(message);
            Broadcast(message);
        }

        private static void SendPrivate(string target, string message)
        {
            lock (locker)
            {
                if (clients.ContainsKey(target))
                {
                    try
                    {
                        var stream = clients[target].GetStream();
                        byte[] data = Encoding.UTF8.GetBytes(message);
                        stream.Write(data, 0, data.Length);
                    }
                    catch { }
                }
            }
        }

        private static void SendUserList()
        {
            string list = "[USERS]" + string.Join(",", clients.Keys);
            Broadcast(list);
        }
    }
}

﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace ChatClientWeek2
{
    public partial class MainWindow : Window
    {
        private TcpClient? client;
        private NetworkStream? stream;

        private DispatcherTimer typingTimer;
        private bool isTyping = false;

        public MainWindow()
        {
            InitializeComponent();
            ApplyTheme("LightTheme"); // default theme

            typingTimer = new DispatcherTimer();
            typingTimer.Interval = TimeSpan.FromSeconds(2); // timeout stop typing
            typingTimer.Tick += TypingTimer_Tick;
        }

        private async void ConnectBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (client == null || !client.Connected)
                {
                    // CONNECT
                    client = new TcpClient();
                    await client.ConnectAsync(IpBox.Text, int.Parse(PortBox.Text));
                    stream = client.GetStream();

                    // kirim username ke server
                    byte[] userData = Encoding.UTF8.GetBytes(UsernameBox.Text);
                    await stream.WriteAsync(userData, 0, userData.Length);

                    ChatList.Items.Add("[System] Connected to server.");
                    ConnectBtn.Content = "Disconnect";

                    _ = ReceiveMessagesAsync();
                }
                else
                {
                    // DISCONNECT
                    Disconnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void Disconnect()
        {
            try
            {
                if (client != null)
                {
                    if (client.Connected)
                    {
                        ChatList.Items.Add("[System] Disconnected.");
                    }
                    stream?.Close();
                    client.Close();
                }
            }
            catch (Exception ex)
            {
                ChatList.Items.Add($"[Error] {ex.Message}");
            }
            finally
            {
                client = null;
                stream = null;
                ConnectBtn.Content = "Connect"; // reset button
                UserList.Items.Clear();
                TypingIndicator.Text = "";
                TypingIndicator.Visibility = Visibility.Collapsed;
            }
        }

        private async Task ReceiveMessagesAsync()
        {
            try
            {
                byte[] buffer = new byte[1024];
                while (client != null && client.Connected)
                {
                    int byteCount = await stream!.ReadAsync(buffer, 0, buffer.Length);
                    if (byteCount == 0) break;

                    string msg = Encoding.UTF8.GetString(buffer, 0, byteCount);

                    Dispatcher.Invoke(() =>
                    {
                        if (msg.StartsWith("[USERS]"))
                        {
                            UserList.Items.Clear();
                            string[] users = msg.Substring(8).Split(',');
                            foreach (var u in users)
                            {
                                if (!string.IsNullOrWhiteSpace(u))
                                    UserList.Items.Add(u);
                            }
                        }
                        else if (msg.StartsWith("[TYPING]"))
                        {
                            string[] parts = msg.Split(':');
                            if (parts.Length >= 3)
                            {
                                string username = parts[1];
                                bool typing = parts[2] == "on";
                                if (username != UsernameBox.Text) // jangan tampilkan typing kita sendiri
                                    UpdateTypingIndicator(username, typing);
                            }
                        }
                        else
                        {
                            ChatList.Items.Add(msg);
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    ChatList.Items.Add($"[Error] {ex.Message}");
                });
            }
            finally
            {
                // ensure cleanup if server disconnects us
                Dispatcher.Invoke(() => Disconnect());
            }
        }

        private async void SendBtn_Click(object sender, RoutedEventArgs e)
        {
            if (stream == null) return;

            string msg = InputBox.Text.Trim();
            if (!string.IsNullOrEmpty(msg))
            {
                byte[] data = Encoding.UTF8.GetBytes(msg);
                await stream.WriteAsync(data, 0, data.Length);
                InputBox.Clear();
            }
        }

        //  Typing Indicator 
        private void InputBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (stream == null) return;

            if (!isTyping)
            {
                isTyping = true;
                SendTypingStatus(true);
                typingTimer.Start();
            }
            else
            {
                typingTimer.Stop();
                typingTimer.Start(); // reset timer tiap input
            }
        }

        private void TypingTimer_Tick(object? sender, EventArgs e)
        {
            isTyping = false;
            SendTypingStatus(false);
            typingTimer.Stop();
        }

        private async void SendTypingStatus(bool typing)
        {
            if (stream == null) return;

            string msg = $"[TYPING]:{UsernameBox.Text}:{(typing ? "on" : "off")}";
            byte[] data = Encoding.UTF8.GetBytes(msg);
            await stream.WriteAsync(data, 0, data.Length);
        }

        private void UpdateTypingIndicator(string username, bool typing)
        {
            TypingIndicator.Text = typing ? $"{username} is typing..." : "";
            TypingIndicator.Visibility = typing ? Visibility.Visible : Visibility.Collapsed;
        }

        //  THEME SWITCHER 
        private void ApplyTheme(string themeFile)
        {
            try
            {
                var dict = new ResourceDictionary
                {
                    Source = new Uri($"Themes/{themeFile}.xaml", UriKind.Relative)
                };
                Application.Current.Resources.MergedDictionaries.Clear();
                Application.Current.Resources.MergedDictionaries.Add(dict);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error applying theme: {ex.Message}");
            }
        }

        private void LightTheme_Click(object sender, RoutedEventArgs e)
        {
            ApplyTheme("LightTheme");
        }

        private void DarkTheme_Click(object sender, RoutedEventArgs e)
        {
            ApplyTheme("DarkTheme");
        }

        private void UserList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }
    }
}

﻿using System.Net;
using System.Net.Sockets;
using System.Text;

class Server
{
    static List<TcpClient> clients = new List<TcpClient>();

    static async Task Main(string[] args)
    {
        int port = 5000;

        // Listen di semua network interface (LAN, WiFi, dll)
        TcpListener server = new TcpListener(IPAddress.Any, port);
        server.Start();
        Console.WriteLine($"Server started on port {port}");
        Console.WriteLine($"Server IP: {GetLocalIPAddress()}");

        while (true)
        {
            TcpClient client = await server.AcceptTcpClientAsync();
            clients.Add(client);
            Console.WriteLine("New client connected!");

            _ = HandleClientAsync(client);
        }
    }

    static async Task HandleClientAsync(TcpClient client)
    {
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];

        try
        {
            while (true)
            {
                int byteCount = await stream.ReadAsync(buffer, 0, buffer.Length);
                if (byteCount == 0) break; // client disconnect

                string message = Encoding.UTF8.GetString(buffer, 0, byteCount);
                Console.WriteLine($"Received: {message}");

                // Broadcast ke semua client
                foreach (var c in clients.ToList())
                {
                    if (c.Connected)
                    {
                        var s = c.GetStream();
                        byte[] data = Encoding.UTF8.GetBytes(message);
                        await s.WriteAsync(data, 0, data.Length);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Client error: {ex.Message}");
        }
        finally
        {
            clients.Remove(client);
            client.Close();
            Console.WriteLine("Client disconnected");
        }
    }

    static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }
        }
        return "No IPv4 address found";
    }
}
﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ChatClient
{
    public partial class MainWindow : Window
    {
        private TcpClient? client;
        private NetworkStream? stream;
        private string? username;
        private static readonly Random rng = new Random();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void ConnectBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                client = new TcpClient();
                await client.ConnectAsync(IpBox.Text, int.Parse(PortBox.Text));
                stream = client.GetStream();

                //  Jika username kosong, generate otomatis
                if (string.IsNullOrWhiteSpace(UsernameBox.Text))
                {
                    username = "User" + rng.Next(1000, 9999);
                }
                else
                {
                    username = UsernameBox.Text.Trim();
                }

                
                byte[] data = Encoding.UTF8.GetBytes(username);
                await stream.WriteAsync(data, 0, data.Length);

                AppendMessage($"Connected to server as {username}!");

                _ = ReceiveMessagesAsync(); 

                ConnectBtn.IsEnabled = false;
            }
            catch (Exception ex)
            {
                AppendMessage($"Error: {ex.Message}");
            }
        }

        private async void SendBtn_Click(object sender, RoutedEventArgs e)
        {
            if (client == null || !client.Connected || stream == null || string.IsNullOrEmpty(username))
                return;

            string text = $"{username}: {MessageBox.Text}";
            byte[] data = Encoding.UTF8.GetBytes(text);

            await stream.WriteAsync(data, 0, data.Length);
            MessageBox.Clear();
        }

        private async Task ReceiveMessagesAsync()
        {
            if (client == null || stream == null) return;

            byte[] buffer = new byte[1024];

            try
            {
                while (client.Connected)
                {
                    int byteCount = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (byteCount == 0) break;

                    string message = Encoding.UTF8.GetString(buffer, 0, byteCount);
                    Dispatcher.Invoke(() => AppendMessage(message));
                }
            }
            catch
            {
                Dispatcher.Invoke(() => AppendMessage("Disconnected from server."));
            }
        }

        private void AppendMessage(string msg)
        {
            ChatList.Items.Add(msg);
        }
    }
}